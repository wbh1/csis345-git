int main(){
    printf("Hi from test.\n");
    pause();
}
